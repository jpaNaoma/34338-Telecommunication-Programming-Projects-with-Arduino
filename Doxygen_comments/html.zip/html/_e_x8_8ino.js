var _e_x8_8ino =
[
    [ "loop", "_e_x8_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_e_x8_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "Blue", "_e_x8_8ino.html#a0857447e42a5eeb608f7d76b06b5b189", null ],
    [ "Green", "_e_x8_8ino.html#a8318c37a6c631573b4e6d149ea1bfea5", null ],
    [ "Potentiometer", "_e_x8_8ino.html#a2603e2031d61df34aecf5244f6d767c7", null ],
    [ "Red", "_e_x8_8ino.html#ac6067dbed47723fd54c1a2c5210c27d5", null ]
];