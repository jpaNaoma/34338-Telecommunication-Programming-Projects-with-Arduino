var ex1_8ino =
[
    [ "loop", "ex1_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "ex1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "space_between_letters", "ex1_8ino.html#aa885582651adf95aa8b84e69e72da2ee", null ],
    [ "streg", "ex1_8ino.html#a2f841eee3bd73d8d106241ae6c327298", null ],
    [ "timeUnit", "ex1_8ino.html#a5f092a3b0e3711533e9d1e03c748e427", null ]
];