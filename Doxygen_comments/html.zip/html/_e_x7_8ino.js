var _e_x7_8ino =
[
    [ "loop", "_e_x7_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_e_x7_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "bluePin", "_e_x7_8ino.html#a4da1253dc00e0a399f4fd9739934f39a", null ],
    [ "greenPin", "_e_x7_8ino.html#ae37e0923aaaabd9060cd4c6960c8ffa8", null ],
    [ "redPin", "_e_x7_8ino.html#a94d4e3dbe688f8dbe66ec032d489bd67", null ]
];