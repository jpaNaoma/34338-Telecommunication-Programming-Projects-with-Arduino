var ex_86_8ino =
[
    [ "loop", "ex_86_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "ex_86_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "incomingChar", "ex_86_8ino.html#a1d1cb01cf4c400bb31765b6ebe44762d", null ],
    [ "mychar", "ex_86_8ino.html#a14e54d5c3f21dd20a072b35a65530d19", null ],
    [ "redLED1", "ex_86_8ino.html#ac41d4387f3da14d20fecbed9aec39ff8", null ],
    [ "redLED2", "ex_86_8ino.html#a691b35c9a0a7c15f7fb082673978019a", null ],
    [ "redLED3", "ex_86_8ino.html#a390bcba0bbda4162e5f299f283c433c2", null ],
    [ "redLED4", "ex_86_8ino.html#a50a8d94c3ba4a10c55ca9a9a89079467", null ],
    [ "redLED5", "ex_86_8ino.html#a4f21a39de5acfa7bb9d2fa7b0427ee2d", null ],
    [ "val", "ex_86_8ino.html#aa0ccb5ee6d882ee3605ff47745c6467b", null ]
];