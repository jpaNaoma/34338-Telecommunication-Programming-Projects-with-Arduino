var struct_animal =
[
    [ "family", "struct_animal.html#a2bc355e2503f608b8fa78040c44b8974", null ],
    [ "isAlive", "struct_animal.html#aab5576c4cdfa09927d4f4491b51c9a8c", null ],
    [ "species", "struct_animal.html#add865dbb186c66544884cf6694af96f8", null ],
    [ "weight", "struct_animal.html#a055c4df7dacb89eb4c2ca9bbee11ff24", null ],
    [ "yearOfCapture", "struct_animal.html#aebae7d702c7dc48d40eea2bcc59f4643", null ]
];