var _exercise__14_8ino =
[
    [ "Animal", "struct_animal.html", "struct_animal" ],
    [ "loop", "_exercise__14_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "printAnimal", "_exercise__14_8ino.html#a401b04415467a0545d2373ffceeb15cf", null ],
    [ "setup", "_exercise__14_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "swapWeight", "_exercise__14_8ino.html#a4801b1dd319de5dfeb1e554c3341b714", null ]
];