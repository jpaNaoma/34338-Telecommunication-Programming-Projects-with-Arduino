var annotated_dup =
[
    [ "Animal", "struct_animal.html", "struct_animal" ]
];