var searchData=
[
  ['space_5fbetween_5fletters_0',['space_between_letters',['../ex1_8ino.html#aa885582651adf95aa8b84e69e72da2ee',1,'ex1.ino']]],
  ['species_1',['species',['../struct_animal.html#add865dbb186c66544884cf6694af96f8',1,'Animal']]],
  ['speed_2',['speed',['../_l_e_d___game_8ino.html#a218b4f7c6cc2681a99c23a3b089d68b1',1,'LED_Game.ino']]],
  ['streg_3',['streg',['../ex1_8ino.html#a2f841eee3bd73d8d106241ae6c327298',1,'ex1.ino']]]
];
