var searchData=
[
  ['sensorpin_0',['sensorPin',['../_display___l_e_ds__and__temp_8ino.html#a6c53d6a30fb5dab269c504c7edc3465e',1,'sensorPin:&#160;Display_LEDs_and_temp.ino'],['../ex11_8ino.html#a6c53d6a30fb5dab269c504c7edc3465e',1,'sensorPin:&#160;ex11.ino']]]
];
