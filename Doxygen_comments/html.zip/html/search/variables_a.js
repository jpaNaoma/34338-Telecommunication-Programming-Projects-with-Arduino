var searchData=
[
  ['pointer_0',['pointer',['../_exercise__13_8ino.html#a920c3777c0b867b61795dc496072835d',1,'Exercise_13.ino']]],
  ['potentiometer_1',['Potentiometer',['../_e_x8_8ino.html#a2603e2031d61df34aecf5244f6d767c7',1,'EX8.ino']]]
];
