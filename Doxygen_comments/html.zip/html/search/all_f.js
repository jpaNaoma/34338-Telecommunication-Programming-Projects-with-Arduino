var searchData=
[
  ['val_0',['val',['../ex_86_8ino.html#aa0ccb5ee6d882ee3605ff47745c6467b',1,'ex.6.ino']]],
  ['var_1',['var',['../_exercise__13_8ino.html#a96c77f9f3a7baec84b9b8add26a31787',1,'Exercise_13.ino']]]
];
