var searchData=
[
  ['x_0',['x',['../_exercise__13_8ino.html#a6150e0515f7202e2fb518f7206ed97dc',1,'Exercise_13.ino']]]
];
