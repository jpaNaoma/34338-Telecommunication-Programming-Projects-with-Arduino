var searchData=
[
  ['sensorpin_0',['sensorPin',['../_display___l_e_ds__and__temp_8ino.html#a6c53d6a30fb5dab269c504c7edc3465e',1,'sensorPin:&#160;Display_LEDs_and_temp.ino'],['../ex11_8ino.html#a6c53d6a30fb5dab269c504c7edc3465e',1,'sensorPin:&#160;ex11.ino']]],
  ['setup_1',['setup',['../ex1_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ex1.ino'],['../_l_e_d___game_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;LED_Game.ino'],['../_exercise__13_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Exercise_13.ino'],['../_exercise__14_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Exercise_14.ino'],['../ex2_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ex2.ino'],['../_e_x3_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;EX3.ino'],['../_ex5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Ex5.ino'],['../ex_86_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ex.6.ino'],['../_e_x7_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;EX7.ino'],['../_e_x8_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;EX8.ino'],['../_display___l_e_ds__and__temp_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;Display_LEDs_and_temp.ino'],['../ex11_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;ex11.ino']]],
  ['space_5fbetween_5fletters_2',['space_between_letters',['../ex1_8ino.html#aa885582651adf95aa8b84e69e72da2ee',1,'ex1.ino']]],
  ['species_3',['species',['../struct_animal.html#add865dbb186c66544884cf6694af96f8',1,'Animal']]],
  ['speed_4',['speed',['../_l_e_d___game_8ino.html#a218b4f7c6cc2681a99c23a3b089d68b1',1,'LED_Game.ino']]],
  ['streg_5',['streg',['../ex1_8ino.html#a2f841eee3bd73d8d106241ae6c327298',1,'ex1.ino']]],
  ['swap_6',['swap',['../_exercise__13_8ino.html#a613f5d8673cc68eff30a4550356f5956',1,'Exercise_13.ino']]],
  ['swapweight_7',['swapWeight',['../_exercise__14_8ino.html#a4801b1dd319de5dfeb1e554c3341b714',1,'Exercise_14.ino']]]
];
