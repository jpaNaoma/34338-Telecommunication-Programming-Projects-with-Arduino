var searchData=
[
  ['family_0',['family',['../struct_animal.html#a2bc355e2503f608b8fa78040c44b8974',1,'Animal']]]
];
