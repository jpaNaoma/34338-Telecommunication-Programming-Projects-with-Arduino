var searchData=
[
  ['green_0',['Green',['../_e_x8_8ino.html#a8318c37a6c631573b4e6d149ea1bfea5',1,'Green:&#160;EX8.ino'],['../_display___l_e_ds__and__temp_8ino.html#a8318c37a6c631573b4e6d149ea1bfea5',1,'Green:&#160;Display_LEDs_and_temp.ino']]],
  ['greenpin_1',['greenPin',['../_e_x7_8ino.html#ae37e0923aaaabd9060cd4c6960c8ffa8',1,'EX7.ino']]]
];
