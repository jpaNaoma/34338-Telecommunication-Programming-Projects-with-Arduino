var _ex5_8ino =
[
    [ "loop", "_ex5_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_ex5_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "incomingByte", "_ex5_8ino.html#ae563354a0218546aca0b276f84a85755", null ]
];