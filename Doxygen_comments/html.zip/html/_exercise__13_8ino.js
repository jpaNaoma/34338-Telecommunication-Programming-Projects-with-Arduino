var _exercise__13_8ino =
[
    [ "loop", "_exercise__13_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "_exercise__13_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "swap", "_exercise__13_8ino.html#a613f5d8673cc68eff30a4550356f5956", null ],
    [ "pointer", "_exercise__13_8ino.html#a920c3777c0b867b61795dc496072835d", null ],
    [ "var", "_exercise__13_8ino.html#a96c77f9f3a7baec84b9b8add26a31787", null ],
    [ "x", "_exercise__13_8ino.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "_exercise__13_8ino.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];